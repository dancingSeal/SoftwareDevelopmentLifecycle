//STEPHANIE DOUGLAS

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
				topDestinationListFrame.setTitle("Top 5 Destination List");
				topDestinationListFrame.setVisible(true);
			}
		});
	}
}

@SuppressWarnings("serial")
class TopDestinationListFrame extends JFrame {
	@SuppressWarnings("rawtypes")
	private DefaultListModel listModel;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public TopDestinationListFrame() {
		super("Top Five Destination List");

		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		// UPDATED SIZE
		setSize(900, 900);

		listModel = new DefaultListModel();

		// TOP 5 DESTINATIONS
		addDestinationNameAndPicture(
				"1. Bora Bora, French Polynesia (Enjoy this seaside luxury vacation surrounded by clear waters and coral reefs.)",
				new ImageIcon(getClass().getResource("/resources/BoraBora.jpg")));
		addDestinationNameAndPicture(
				"2. Kauai, Hawaii (Come visit the oldest Hawaiian island to enjoy the true beauty of Hawaiian culture and beautiful mountains and beaches.)",
				new ImageIcon(getClass().getResource("/resources/Hawaii.jpg")));
		addDestinationNameAndPicture(
				"3. Bali, Indonesia (This island is a tropical paradise. Come enjoy the beautiful art, watch the locals dance, and the lush scenery.)",
				new ImageIcon(getClass().getResource("/resources/Bali.jpg")));
		addDestinationNameAndPicture(
				"4. Harbour Island, Bahamas (Harbour Islands is notorious for its long stretching pink beach and coral reefs, making the perfect destination for snorkeling and swimming adventures.)",
				new ImageIcon(getClass().getResource("/resources/Bahamas.jpg")));
		addDestinationNameAndPicture(
				"5. Fiji (Fiji located in the South Pacific Ocean have white sand beaches, coconuts, warm water, and amazing food.)",
				new ImageIcon(getClass().getResource("/resources/Fiji.jpg")));

		JList list = new JList(listModel);
		JScrollPane scrollPane = new JScrollPane(list);

		TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);

		list.setCellRenderer(renderer);

		getContentPane().add(scrollPane, BorderLayout.CENTER);
		
		//ADD LABEL
		JLabel nameLabel = new JLabel("Developer: Stephanie Douglas");
		getContentPane().add(nameLabel, BorderLayout.NORTH);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
	}

	@SuppressWarnings("unchecked")
	private void addDestinationNameAndPicture(String text, Icon icon) {
		TextAndIcon tai = new TextAndIcon(text, icon);
		listModel.addElement(tai);
	}
}

class TextAndIcon {
	private String text;
	private Icon icon;

	public TextAndIcon(String text, Icon icon) {
		this.text = text;
		this.icon = icon;
	}

	public String getText() {
		return text;
	}

	public Icon getIcon() {
		return icon;
	}

	public void setText(String text) {
		this.text = text;
	}

	public void setIcon(Icon icon) {
		this.icon = icon;
	}
}


@SuppressWarnings({ "serial", "rawtypes" })
class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
	private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

	private Border insideBorder;

	public TextAndIconListCellRenderer() {
		this(0, 0, 0, 0);
	}

	public TextAndIconListCellRenderer(int padding) {
		this(padding, padding, padding, padding);
	}

	public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
		insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
		setOpaque(true);
	}

	public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
			boolean hasFocus) {
		// The object from the combo box model MUST be a TextAndIcon.
		TextAndIcon tai = (TextAndIcon) value;

		// Sets text and icon on 'this' JLabel.
		setText(tai.getText());
		setIcon(tai.getIcon());

		// SET BACKGROUND AND SELECTION BACKGROUND COLORS
		list.setSelectionBackground(Color.GRAY);
		list.setBackground(Color.LIGHT_GRAY);

		if (isSelected) {
			setBackground(list.getSelectionBackground());
			setForeground(list.getSelectionForeground());
		} else {
			setBackground(list.getBackground());
			setForeground(list.getForeground());
		}

		Border outsideBorder;

		if (hasFocus) {
			outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
		} else {
			outsideBorder = NO_FOCUS_BORDER;
		}

		setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
		setComponentOrientation(list.getComponentOrientation());
		setEnabled(list.isEnabled());
		setFont(list.getFont());

		return this;
	}

	// The following methods are overridden to be empty for performance
	// reasons. If you want to understand better why, please read:
	//
	// http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

	public void validate() {
	}

	public void invalidate() {
	}

	public void repaint() {
	}

	public void revalidate() {
	}

	public void repaint(long tm, int x, int y, int width, int height) {
	}

	public void repaint(Rectangle r) {
	}
}